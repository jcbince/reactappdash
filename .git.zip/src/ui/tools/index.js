import styled from 'styled-components';

const ToolBar = styled.nav`
     padding: 1rem;
     box-shadow:0 0 2px 0 grey;
`;

export{ToolBar} ;