 import React from 'react'
 
import {TextArea} from "ui/forms/textarea"

 function TextAreaControl  (props){
     return( 
         <TextArea></TextArea>
     )
 }
 
 export default TextAreaControl 