import styled from 'styled-components';



const AddProductStyles  = styled.div`
      /* styles */
      h2{
          font-size:1.75rem;
          color:#374151;
      }
`;

export {AddProductStyles}