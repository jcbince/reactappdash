import styled from 'styled-components';



const ProductImageDropBoxStyles  = styled.div`
      /* styles */
      
      h2{
          font-size:1.75rem;
          color:#374151;
          background-color:grey;
          border: 2px solid black;
          padding:3rem
      }
`;

export {ProductImageDropBoxStyles}