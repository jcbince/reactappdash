export{default as AllProductsPanel} from './DeleteProductPanel'
export{default as AddProductPanel} from './AddProductPanel'
export{default as UpdateProductPanel} from './UpdateProductPanel'
export{default as DeleteProductPanel} from './DeleteProductPanel'