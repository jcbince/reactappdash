import React from 'react'


const Delete = (props) => {
  return (
	<div>
	  	<h1>Delete Here</h1>
	</div>
  )
}

export default Delete
