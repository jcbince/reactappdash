import React from 'react'




const Add = (props) => {
  return (
	<div>
	  	<h1>ADD HERE</h1>
	</div>
  )
}

export default Add
