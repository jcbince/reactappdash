export {default as DashBoardPage} from './dashboard/DashBoardPage'
export {default as LoginPage} from './login/LoginPage'
export {default as PageNotFound} from './404/PageNotFound'
export {default as Add } from './add/Add'
export {default as Delete} from './delete/Delete'
export {default as Update} from './update/Update'

