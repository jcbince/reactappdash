import React from 'react'




const Update = (props) => {
  return (
	<div>

	  	<h1>Update</h1>
	</div>
  )
}

export default Update
